// selected puzzles for Fall 2015
int minusOne();
int test_minusOne();
int oddBits();
int test_oddBits();
int copyLSB(int);
int test_copyLSB(int);
int addOK(int, int);
int test_addOK(int, int);
